from . import linear_chain

__all__ = ['linear_chain']
